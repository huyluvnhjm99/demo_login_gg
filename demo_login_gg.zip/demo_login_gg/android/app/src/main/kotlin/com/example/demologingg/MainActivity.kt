package com.example.demologingg

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
